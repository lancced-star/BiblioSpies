<?php
try {
    $bdd = new PDO('mysql:host=localhost;dbname=biblioSpies;charset=utf8', 'root', '');
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur de connexion à la base de données.');
}
?>